public enum Type {
    Chen,
    Boul,
    Sapi;
}
