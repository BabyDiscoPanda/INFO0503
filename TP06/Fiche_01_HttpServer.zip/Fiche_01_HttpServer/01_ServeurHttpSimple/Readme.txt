1) Compilez les classes :
  > javac *.java
2) Executez le serveur :
  > java ServeurHttpSimple
3) Ouvrez le fichier testServeurHttpSimple.html dans un navigateur Internet puis testez les deux boutons
